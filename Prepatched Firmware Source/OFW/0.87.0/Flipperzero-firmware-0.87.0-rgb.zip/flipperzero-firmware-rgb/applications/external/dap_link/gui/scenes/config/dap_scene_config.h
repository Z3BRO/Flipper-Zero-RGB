ADD_SCENE(dap, main, Main)
ADD_SCENE(dap, config, Config)
ADD_SCENE(dap, help, Help)
ADD_SCENE(dap, about, About)