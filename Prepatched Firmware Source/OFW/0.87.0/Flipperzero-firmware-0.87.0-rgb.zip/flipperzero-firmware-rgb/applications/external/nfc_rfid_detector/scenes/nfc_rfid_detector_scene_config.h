ADD_SCENE(nfc_rfid_detector, start, Start)
ADD_SCENE(nfc_rfid_detector, about, About)
ADD_SCENE(nfc_rfid_detector, field_presence, FieldPresence)
