#pragma once

#include <lib/subghz/protocols/base.h>

#define WS_PROTOCOL_OREGON3_NAME "Oregon3"
extern const SubGhzProtocol ws_protocol_oregon3;
