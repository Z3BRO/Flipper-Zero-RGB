#pragma once

typedef enum {
    //NfcRfidDetectorCustomEvent
    NfcRfidDetectorCustomEventStartId = 100,

} NfcRfidDetectorCustomEvent;
