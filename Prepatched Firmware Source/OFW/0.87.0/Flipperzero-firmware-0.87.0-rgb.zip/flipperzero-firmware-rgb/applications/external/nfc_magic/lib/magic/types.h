#pragma once

#include "common.h"

const char* nfc_magic_type(MagicType type);