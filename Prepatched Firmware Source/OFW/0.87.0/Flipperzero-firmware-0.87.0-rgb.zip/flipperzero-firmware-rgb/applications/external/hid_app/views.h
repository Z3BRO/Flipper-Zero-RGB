typedef enum {
    HidViewSubmenu,
    HidViewKeynote,
    HidViewKeyboard,
    HidViewMedia,
    HidViewMouse,
    HidViewMouseClicker,
    HidViewMouseJiggler,
    BtHidViewTikTok,
    HidViewExitConfirm,
} HidView;