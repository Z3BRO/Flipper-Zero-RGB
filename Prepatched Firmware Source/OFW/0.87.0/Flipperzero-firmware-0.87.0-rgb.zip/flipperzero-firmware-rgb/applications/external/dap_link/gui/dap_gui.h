#pragma once
#include <stdint.h>

int32_t dap_gui_thread(void* arg);