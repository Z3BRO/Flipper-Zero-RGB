ADD_SCENE(lfrfid_debug, start, Start)
ADD_SCENE(lfrfid_debug, tune, Tune)
