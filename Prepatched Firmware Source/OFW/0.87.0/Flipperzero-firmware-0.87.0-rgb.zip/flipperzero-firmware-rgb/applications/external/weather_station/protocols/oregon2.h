#pragma once

#include <lib/subghz/protocols/base.h>

#define WS_PROTOCOL_OREGON2_NAME "Oregon2"
extern const SubGhzProtocol ws_protocol_oregon2;
