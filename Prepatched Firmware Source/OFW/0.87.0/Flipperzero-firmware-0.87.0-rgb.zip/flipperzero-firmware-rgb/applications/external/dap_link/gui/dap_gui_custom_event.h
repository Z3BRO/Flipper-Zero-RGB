#pragma once

typedef enum {
    DapAppCustomEventConfig,
    DapAppCustomEventHelp,
    DapAppCustomEventAbout,
} DapAppCustomEvent;
