#pragma once
#include "../subghz_test_app_i.h"

extern const uint32_t subghz_frequencies_testing[];
extern const uint32_t subghz_frequencies_count_testing;
extern const uint32_t subghz_frequencies_433_92_testing;
